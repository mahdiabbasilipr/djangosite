from django.db import models
from django.contrib.auth.models import User


class Article(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField()
    body = models.TextField()
    date = models.DateTimeField(auto_now_add=True)
    # blank=True ro mizarim ta beshe aghar khastim image default ro ham hazf konim
    image = models.ImageField(default='default.jpg', blank=True)
    # add in author
    author = models.ForeignKey(User, default=None, on_delete=models.CASCADE)

    # baraye inke dar safhe admin dorost neshon bede title ro
    def __str__(self):
        return self.title

    # baraye inke  body ro dar safhe maghalat kotah neshon bede
    def short_body(self):
        return self.body[:300] + '...'
