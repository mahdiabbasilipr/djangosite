from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse
from . import models
from django.contrib.auth.decorators import login_required
from . import forms


def articels(request):
    # dar code zir tamame maghalat mojod dar database ro dar yek list zakhire mikonim
    articels = models.Article.objects.all().order_by('date')

    # hame maghadir list ro ham vared dictionary mikonim
    args = {'articles': articels}

    # dictionary maghalat ro baraye file html khodemon ersal mikonim
    return render(request, 'articels/articelslist.html', args)


def article_detail(request, slug):
    # hameye maghalati ke slug on ha ba slug daryaft shode tavasot urls yeki bashe ro migire
    articles = models.Article.objects.get(slug=slug)
    return render(request, 'articels/article_detail.html', {'articles': articles})


# komak mikone ke bebinim karbar login hast ya na
@login_required(login_url="/accounts/login")
def create_article(request):

    if request.method == "POST":
        form = forms.CreateArticle(request.POST, request.FILES)
        if form.is_valid():
            #user ro set m
            instance = form.save(commit = False)
            instance.author = request.user
            instance.save()
            return redirect("articles:list")
    else:
        form = forms.CreateArticle
    return render(request, 'articels/create_article.html', {'form': form})
