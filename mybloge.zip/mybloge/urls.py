from django.contrib import admin
from django.urls import path, include
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from articels.views import articels
# import file setting baraye tashkhis setting hayi ke anjam dadim
from django.conf import settings
# import static baraye dastresi be maghadir urls
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),
    path('about/', views.about),

    path('articels/', include('articels.urls')),
    path('accounts/', include('accounts.urls')),
    path('', articels),
]

# url haye static ro be url haye asli ezafe mikone
# ta betonim file haye image,css ro az database biarim
urlpatterns += staticfiles_urlpatterns()
# url haro be file mediayi ke ijad kardim va dar setting tarif kardim motasel mikonim
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
